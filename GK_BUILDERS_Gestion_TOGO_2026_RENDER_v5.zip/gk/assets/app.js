function showModal(id){const e=document.getElementById(id);if(e)e.classList.add('show')}
function hideModal(id){const e=document.getElementById(id);if(e)e.classList.remove('show')}
window.addEventListener('click',e=>{if(e.target.classList.contains('modal'))e.target.classList.remove('show')})
function setSalary(sel){const o=sel.options[sel.selectedIndex];const b=document.getElementById('base');if(b)b.value=o.dataset.salary||0}
function showPassword(id,name){document.getElementById('passId').value=id;document.getElementById('passTitle').innerText='Mot de passe — '+name;showModal('passModal')}
function editCourier(c){document.getElementById('ecid').value=c.id;document.getElementById('ecsub').value=c.subject;document.getElementById('ecbody').value=c.body;showModal('editCourierModal')}
function editProject(p){document.getElementById('epid').value=p.id;document.getElementById('eptitle').value=p.title;document.getElementById('epdesc').value=p.description;showModal('editProjectModal')}
function editWork(w){document.getElementById('ewid').value=w.id;document.getElementById('ewtitle').value=w.title;document.getElementById('ewbody').value=w.content;showModal('editWorkModal')}
function printText(title,body){const w=window.open('','_blank');w.document.write('<!doctype html><html><head><title>'+escapeHtml(title)+'</title><style>body{font-family:Arial;padding:40px}h1{border-bottom:2px solid #222;padding-bottom:10px;white-space:pre-wrap}.body{white-space:pre-wrap;line-height:1.6}</style></head><body><h1>'+escapeHtml(title)+'</h1><div class="body">'+escapeHtml(body)+'</div><script>window.print()<\\/script></body></html>');w.document.close()}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function copyEditor(){const t=document.getElementById('editorTitle').value;const b=document.getElementById('editor').innerText;navigator.clipboard?.writeText((t?t+'\n\n':'')+b);alert('Texte copié. Vous pouvez le coller dans Word.')}
function printEditor(){const t=document.getElementById('editorTitle').value||'Document G&K/BUILDERS';const b=document.getElementById('editor').innerText;printText(t,b)}
