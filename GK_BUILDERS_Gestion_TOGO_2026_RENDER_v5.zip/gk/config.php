<?php
declare(strict_types=1);
session_start();

const COMPANY = 'G&K/BUILDERS';
const DB_DIR = __DIR__ . '/data';
const DB_FILE = DB_DIR . '/gk_builders.sqlite';
if (!is_dir(DB_DIR)) mkdir(DB_DIR, 0775, true);

function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;
    $databaseUrl = getenv('DATABASE_URL') ?: '';
    if ($databaseUrl !== '') {
        $parts = parse_url($databaseUrl);
        if (!$parts || empty($parts['host'])) throw new RuntimeException('DATABASE_URL invalide.');
        $dsn = 'pgsql:host='.$parts['host'].';port='.($parts['port'] ?? 5432).';dbname='.ltrim($parts['path'] ?? '', '/');
        $pdo = new PDO($dsn, $parts['user'] ?? '', $parts['pass'] ?? '', [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    } else {
        $pdo = new PDO('sqlite:' . DB_FILE, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
        $pdo->exec('PRAGMA foreign_keys = ON');
    }
    initialize_db($pdo);
    return $pdo;
}

function initialize_db(PDO $pdo): void {
    $pg = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'pgsql';
    if ($pg) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id BIGSERIAL PRIMARY KEY, username VARCHAR(100) UNIQUE NOT NULL, password TEXT NOT NULL, role VARCHAR(40) NOT NULL DEFAULT 'admin', display_name VARCHAR(150) NOT NULL DEFAULT '')");
        $pdo->exec("CREATE TABLE IF NOT EXISTS employees (id BIGSERIAL PRIMARY KEY, matricule VARCHAR(100) UNIQUE NOT NULL, nom VARCHAR(150) NOT NULL, postnom VARCHAR(150), prenom VARCHAR(150), sexe VARCHAR(30), fonction VARCHAR(150), telephone VARCHAR(50), adresse TEXT, date_embauche DATE, salaire_base NUMERIC(14,2) NOT NULL DEFAULT 0, statut VARCHAR(30) NOT NULL DEFAULT 'Actif', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, cnss_numero VARCHAR(100), personnes_charge INTEGER NOT NULL DEFAULT 0)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS payroll (id BIGSERIAL PRIMARY KEY, employee_id BIGINT NOT NULL REFERENCES employees(id) ON DELETE CASCADE, periode VARCHAR(50) NOT NULL, salaire_base NUMERIC(14,2) NOT NULL, primes NUMERIC(14,2) NOT NULL DEFAULT 0, retenues NUMERIC(14,2) NOT NULL DEFAULT 0, avances NUMERIC(14,2) NOT NULL DEFAULT 0, impots NUMERIC(14,2) NOT NULL DEFAULT 0, net NUMERIC(14,2) NOT NULL, date_paiement DATE, cnss_salarie NUMERIC(14,2) NOT NULL DEFAULT 0, cnss_employeur NUMERIC(14,2) NOT NULL DEFAULT 0, amu_salarie NUMERIC(14,2) NOT NULL DEFAULT 0, amu_employeur NUMERIC(14,2) NOT NULL DEFAULT 0)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS transactions (id BIGSERIAL PRIMARY KEY, type VARCHAR(30) NOT NULL CHECK(type IN ('Recette','Dépense')), libelle VARCHAR(255) NOT NULL, montant NUMERIC(14,2) NOT NULL, date_operation DATE NOT NULL, reference VARCHAR(150), created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS attendance (id BIGSERIAL PRIMARY KEY, employee_id BIGINT NOT NULL REFERENCES employees(id) ON DELETE CASCADE, date_presence DATE NOT NULL, statut VARCHAR(30) NOT NULL, commentaire TEXT)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS correspondence (id BIGSERIAL PRIMARY KEY, sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, recipient_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, subject VARCHAR(255) NOT NULL, body TEXT NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'Envoyé', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS projects (id BIGSERIAL PRIMARY KEY, sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, recipient_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, title VARCHAR(255) NOT NULL, description TEXT NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'Nouveau', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS work_reports (id BIGSERIAL PRIMARY KEY, employee_user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, title VARCHAR(255) NOT NULL, content TEXT NOT NULL, status VARCHAR(30) NOT NULL DEFAULT 'Envoyé', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS access_attempts (id BIGSERIAL PRIMARY KEY, user_id BIGINT REFERENCES users(id) ON DELETE SET NULL, attempted_page VARCHAR(100) NOT NULL, ip_address VARCHAR(100), created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP)");
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin', display_name TEXT NOT NULL DEFAULT '')");
        $pdo->exec("CREATE TABLE IF NOT EXISTS employees (id INTEGER PRIMARY KEY AUTOINCREMENT, matricule TEXT UNIQUE NOT NULL, nom TEXT NOT NULL, postnom TEXT, prenom TEXT, sexe TEXT, fonction TEXT, telephone TEXT, adresse TEXT, date_embauche TEXT, salaire_base REAL NOT NULL DEFAULT 0, statut TEXT NOT NULL DEFAULT 'Actif', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, cnss_numero TEXT, personnes_charge INTEGER NOT NULL DEFAULT 0)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS payroll (id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, periode TEXT NOT NULL, salaire_base REAL NOT NULL, primes REAL NOT NULL DEFAULT 0, retenues REAL NOT NULL DEFAULT 0, avances REAL NOT NULL DEFAULT 0, impots REAL NOT NULL DEFAULT 0, net REAL NOT NULL, date_paiement TEXT, cnss_salarie REAL NOT NULL DEFAULT 0, cnss_employeur REAL NOT NULL DEFAULT 0, amu_salarie REAL NOT NULL DEFAULT 0, amu_employeur REAL NOT NULL DEFAULT 0, FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL CHECK(type IN ('Recette','Dépense')), libelle TEXT NOT NULL, montant REAL NOT NULL, date_operation TEXT NOT NULL, reference TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS attendance (id INTEGER PRIMARY KEY AUTOINCREMENT, employee_id INTEGER NOT NULL, date_presence TEXT NOT NULL, statut TEXT NOT NULL, commentaire TEXT, FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS correspondence (id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER NOT NULL, recipient_id INTEGER NOT NULL, subject TEXT NOT NULL, body TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Envoyé', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(recipient_id) REFERENCES users(id) ON DELETE CASCADE)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS projects (id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER NOT NULL, recipient_id INTEGER NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Nouveau', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(recipient_id) REFERENCES users(id) ON DELETE CASCADE)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS work_reports (id INTEGER PRIMARY KEY AUTOINCREMENT, employee_user_id INTEGER NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Envoyé', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(employee_user_id) REFERENCES users(id) ON DELETE CASCADE)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS access_attempts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, attempted_page TEXT NOT NULL, ip_address TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)");
    }
    // Migration for installations created with the previous version.
    try { $pdo->exec("ALTER TABLE users ADD COLUMN display_name TEXT NOT NULL DEFAULT ''"); } catch (Throwable $e) {}

    $accounts = [
        ['admin','admin123','admin','Administrateur'],
        ['secretaire','GKsec2026!','secretaire','Secrétaire'],
        ['dg1','GKdg1-2026!','dg','DG 1'],
        ['dg2','GKdg2-2026!','dg','DG 2'],
        ['dg3','GKdg3-2026!','dg','DG 3'],
        ['architecte1','GKarch1-2026!','architecte','Architecte 1'],
        ['architecte2','GKarch2-2026!','architecte','Architecte 2'],
        ['ingenieur','GKing-2026!','ingenieur','Ingénieur bâtiment'],
        ['comptabilite','GKcompta-2026!','comptable','Comptabilité'],
        ['personnel','GKpers-2026!','personnel','Personnel'],
    ];
    $st=$pdo->prepare('SELECT id FROM users WHERE username=?');
    $ins=$pdo->prepare('INSERT INTO users(username,password,role,display_name) VALUES(?,?,?,?)');
    foreach($accounts as $a){$st->execute([$a[0]]); if(!$st->fetch()) $ins->execute([$a[0],password_hash($a[1],PASSWORD_DEFAULT),$a[2],$a[3]]);}
}
function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
function money(float $n): string { return number_format($n, 0, ',', ' ') . ' FCFA'; }
function redirect(string $url): never { header('Location: '.$url); exit; }
function flash(?string $message=null): ?string { if($message!==null) $_SESSION['flash']=$message; $x=$_SESSION['flash']??null; unset($_SESSION['flash']); return $x; }
function csrf(): string { if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function check_csrf(): void { if(!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')){http_response_code(419);exit('Jeton de sécurité invalide.');} }
function require_login(): void { if(empty($_SESSION['user'])) redirect('login.php'); }
function user_role(): string { return $_SESSION['user']['role'] ?? ''; }
function is_admin(): bool { return user_role()==='admin'; }
function can_access(string $page): bool {
    $role=user_role();
    if($role==='admin') return true;
    $map=[
        'dashboard'=>['secretaire','dg','architecte','ingenieur','comptable','personnel'],
        'database'=>['secretaire','dg','comptable'],
        'courriers'=>['secretaire','dg','architecte','ingenieur'],
        'projets'=>['dg','architecte','ingenieur'],
        'employees'=>['secretaire','comptable'],
        'payroll'=>['comptable'],
        'transactions'=>['comptable'],
        'attendance'=>['secretaire','comptable','personnel'],
        'travail'=>['personnel'],
        'users'=>[], 'settings'=>[]
    ];
    return in_array($role,$map[$page]??[],true);
}
function can_access_database(): bool {
    return in_array(user_role(), ['secretaire','dg','comptable'], true) || is_admin();
}
function log_access_attempt(PDO $pdo, int $uid, string $page): void {
    try {
        $s=$pdo->prepare('INSERT INTO access_attempts(user_id,attempted_page,ip_address) VALUES(?,?,?)');
        $s->execute([$uid,$page,$_SERVER['REMOTE_ADDR']??'inconnu']);
    } catch (Throwable $e) {}
}
function role_label(string $role): string { return ['admin'=>'Administrateur','secretaire'=>'Secrétaire','dg'=>'Directeur général','architecte'=>'Architecte','ingenieur'=>'Ingénieur bâtiment','comptable'=>'Comptabilité','personnel'=>'Personnel'][$role] ?? $role; }
