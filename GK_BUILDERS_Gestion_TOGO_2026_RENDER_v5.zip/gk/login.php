<?php
require __DIR__.'/config.php';
if (!empty($_SESSION['user'])) redirect('index.php');
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 check_csrf(); $stmt=db()->prepare('SELECT * FROM users WHERE username=?'); $stmt->execute([trim($_POST['username']??'')]); $u=$stmt->fetch();
 if($u && password_verify($_POST['password']??'',$u['password'])){session_regenerate_id(true);$_SESSION['user']=['id'=>$u['id'],'username'=>$u['username'],'role'=>$u['role'],'display_name'=>$u['display_name']];redirect('index.php');}
 $error='Identifiants incorrects.';
}
?><!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Connexion — G&K/BUILDERS</title><link rel="stylesheet" href="assets/style.css"></head><body class="login"><div class="login-card"><div class="brand"><div class="logo">G&K</div><div><strong>G&K/BUILDERS</strong><small>Gestion d'entreprise</small></div></div><h1>Authentification</h1><p class="hint">Chaque utilisateur accède uniquement à son espace de travail.</p><?php if($error):?><div class="alert danger"><?=e($error)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><label>USER<input name="username" required autocomplete="username"></label><label>Mot de passe<input type="password" name="password" required autocomplete="current-password"></label><button class="btn primary full">Se connecter</button></form><div class="login-note"><b>Comptes initiaux</b><br>Voir le tableau des identifiants remis avec le projet.</div></div></body></html>
