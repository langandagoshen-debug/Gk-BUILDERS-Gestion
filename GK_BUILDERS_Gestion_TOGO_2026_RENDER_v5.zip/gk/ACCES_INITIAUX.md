# G&K/BUILDERS — Comptes d'accès initiaux

> À modifier après la première connexion.

| Fonction | USER | Mot de passe |
|---|---|---|
| Administrateur | `admin` | `admin123` |
| Secrétaire | `secretaire` | `GKsec2026!` |
| DG 1 | `dg1` | `GKdg1-2026!` |
| DG 2 | `dg2` | `GKdg2-2026!` |
| DG 3 | `dg3` | `GKdg3-2026!` |
| Architecte 1 | `architecte1` | `GKarch1-2026!` |
| Architecte 2 | `architecte2` | `GKarch2-2026!` |
| Ingénieur bâtiment | `ingenieur` | `GKing-2026!` |
| Comptabilité | `comptabilite` | `GKcompta-2026!` |
| Personnel | `personnel` | `GKpers-2026!` |

## Accès
- Chaque utilisateur dispose d'un espace selon son rôle.
- Les courriers et projets ne montrent que les éléments dont l'utilisateur est expéditeur ou destinataire.
- Le secrétariat peut suivre les courriers et les accusés de réception.
- Les DG, architectes et l'ingénieur disposent du module Projets.
- La comptabilité dispose de Paie, Comptabilité et du bouton Excel.
- Le personnel dispose de Mon travail avec saisie, modification et suppression.
- Les boutons Word/Excel utilisent les protocoles Microsoft lorsqu'ils sont disponibles sur l'ordinateur. Le navigateur peut demander confirmation.
- Les projets/courriers sont enregistrés dans la base de données. Pour une conservation locale sur le PC d'un utilisateur, il faut télécharger/exporter le document ; une application web ne peut pas écrire silencieusement dans le disque local.
