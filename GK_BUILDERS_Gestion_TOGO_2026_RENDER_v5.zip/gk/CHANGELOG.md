# G&K/BUILDERS — Togo
- Pays de référence : Togo
- Devise : FCFA
- CNSS salarié : 4%
- CNSS employeur : 17,5%
- AMU : 10% au total, 5% au moins employeur et 5% salarié pour les travailleurs salariés
- Ajout du numéro CNSS et des personnes à charge dans le dossier salarié
- Calcul automatique des cotisations CNSS/AMU dans la paie
- IRPP laissé paramétrable pour respecter le barème OTR applicable
- Fiche de paie enrichie avec les cotisations sociales
