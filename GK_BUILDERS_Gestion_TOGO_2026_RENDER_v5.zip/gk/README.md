# G&K/BUILDERS — Gestion d'entreprise (Togo)

Application PHP 8.3 dynamique pour la gestion du personnel, des présences, de la paie et de la comptabilité.

## Base de données
- En local : SQLite est utilisée automatiquement dans `data/gk_builders.sqlite`.
- Sur Render : PostgreSQL est utilisé automatiquement lorsque `DATABASE_URL` est définie.
- Les données saisies sont ensuite récupérées depuis la base : recherche des travailleurs par nom, matricule, téléphone ou fonction, consultation de leur fiche, paie, présences et opérations.

## Déploiement Render
1. Mettre ce projet dans un dépôt GitHub.
2. Sur Render, créer une base PostgreSQL.
3. Créer un **Web Service** depuis le dépôt GitHub.
4. Choisir **Docker** (le `Dockerfile` est déjà inclus).
5. Ajouter la variable d'environnement `DATABASE_URL` avec l'URL interne de la base PostgreSQL.
6. Déployer.

## Connexion initiale
Utilisateur : `admin`
Mot de passe : `admin123`

**À changer immédiatement après la première connexion.**

## Modules
- Tableau de bord
- Personnel avec recherche et consultation des dossiers
- Présences
- Paie et impression
- Comptabilité
- Utilisateurs et mots de passe
- Paramètres sociaux Togo (les règles fiscales IRPP doivent être validées et paramétrées selon la réglementation en vigueur)

## Nouveaux espaces utilisateurs
La version actuelle ajoute une authentification par rôle, les espaces Secrétaire, DG, Architectes, Ingénieur bâtiment, Comptabilité et Personnel, ainsi que les modules Courriers, Projets et Mon travail. Voir `ACCES_INITIAUX.md` pour les comptes de démonstration.
