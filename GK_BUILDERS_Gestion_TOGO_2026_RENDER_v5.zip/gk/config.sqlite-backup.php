<?php
declare(strict_types=1);
session_start();

const COMPANY = 'G&K/BUILDERS';
const DB_DIR = __DIR__ . '/data';
const DB_FILE = DB_DIR . '/gk_builders.sqlite';

if (!is_dir(DB_DIR)) mkdir(DB_DIR, 0775, true);

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        initialize_db($pdo);
    }
    return $pdo;
}

function initialize_db(PDO $pdo): void {
    $pdo->exec("PRAGMA foreign_keys = ON");
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'admin'
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS employees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        matricule TEXT UNIQUE NOT NULL,
        nom TEXT NOT NULL,
        postnom TEXT,
        prenom TEXT,
        sexe TEXT,
        fonction TEXT,
        telephone TEXT,
        adresse TEXT,
        date_embauche TEXT,
        salaire_base REAL NOT NULL DEFAULT 0,
        statut TEXT NOT NULL DEFAULT 'Actif',
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS payroll (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id INTEGER NOT NULL,
        periode TEXT NOT NULL,
        salaire_base REAL NOT NULL,
        primes REAL NOT NULL DEFAULT 0,
        retenues REAL NOT NULL DEFAULT 0,
        avances REAL NOT NULL DEFAULT 0,
        impots REAL NOT NULL DEFAULT 0,
        net REAL NOT NULL,
        date_paiement TEXT,
        FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        type TEXT NOT NULL CHECK(type IN ('Recette','Dépense')),
        libelle TEXT NOT NULL,
        montant REAL NOT NULL,
        date_operation TEXT NOT NULL,
        reference TEXT,
        created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employee_id INTEGER NOT NULL,
        date_presence TEXT NOT NULL,
        statut TEXT NOT NULL,
        commentaire TEXT,
        FOREIGN KEY(employee_id) REFERENCES employees(id) ON DELETE CASCADE
    )");
    // Togo payroll fields: CNSS number and dependants.
    $cols = $pdo->query("PRAGMA table_info(employees)")->fetchAll();
    $names = array_column($cols, 'name');
    if (!in_array('cnss_numero', $names, true)) $pdo->exec("ALTER TABLE employees ADD COLUMN cnss_numero TEXT");
    if (!in_array('personnes_charge', $names, true)) $pdo->exec("ALTER TABLE employees ADD COLUMN personnes_charge INTEGER NOT NULL DEFAULT 0");
    $pcols = $pdo->query("PRAGMA table_info(payroll)")->fetchAll();
    $pnames = array_column($pcols, 'name');
    if (!in_array('cnss_salarie', $pnames, true)) $pdo->exec("ALTER TABLE payroll ADD COLUMN cnss_salarie REAL NOT NULL DEFAULT 0");
    if (!in_array('cnss_employeur', $pnames, true)) $pdo->exec("ALTER TABLE payroll ADD COLUMN cnss_employeur REAL NOT NULL DEFAULT 0");
    if (!in_array('amu_salarie', $pnames, true)) $pdo->exec("ALTER TABLE payroll ADD COLUMN amu_salarie REAL NOT NULL DEFAULT 0");
    if (!in_array('amu_employeur', $pnames, true)) $pdo->exec("ALTER TABLE payroll ADD COLUMN amu_employeur REAL NOT NULL DEFAULT 0");

    $count = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    if ($count === 0) {
        $stmt = $pdo->prepare("INSERT INTO users(username,password,role) VALUES(?,?,?)");
        $stmt->execute(['admin', password_hash('admin123', PASSWORD_DEFAULT), 'admin']);
    }
}

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
function money(float $n): string { return number_format($n, 0, ',', ' ') . ' FCFA'; }
function redirect(string $url): never { header('Location: ' . $url); exit; }
function flash(?string $message = null): ?string {
    if ($message !== null) $_SESSION['flash'] = $message;
    $x = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $x;
}
function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['csrf'];
}
function check_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('Jeton de sécurité invalide.'); }
}
function require_login(): void { if (empty($_SESSION['user'])) redirect('login.php'); }
